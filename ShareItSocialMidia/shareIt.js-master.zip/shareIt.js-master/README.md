# shareIt.js
shareIt.js is a Social Content Unlocker. With shareIt, you can lock anything in your content and the content will be automatically unlocked when user share it on Social Media.You can use this plugin to increase your social media followers and your content shares.

Full documentation is available at http://mycodingtricks.com/jquery/shareit-js-social-content-unlocker/

Check demo at http://demo.mycodingtricks.com/jquery/shareit-js-social-content-unlocker/
